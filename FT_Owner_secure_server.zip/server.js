require("dotenv").config();

const express = require("express");
const crypto = require("crypto");
const argon2 = require("argon2");
const Database = require("better-sqlite3");
const { authenticator } = require("otplib");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

if (!process.env.ADMIN_LOGIN || !process.env.ADMIN_PASSWORD ||
    !process.env.TOTP_SECRET || !process.env.SESSION_SECRET) {
  throw new Error("Missing required environment variables. Copy .env.example to .env and configure it.");
}

if (process.env.ADMIN_PASSWORD.length < 12) {
  throw new Error("ADMIN_PASSWORD must be at least 12 characters.");
}

const db = new Database("ft-owner.db");
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    login TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    two_factor_ok INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

(async () => {
  const existing = db.prepare("SELECT id FROM users WHERE login = ?").get(process.env.ADMIN_LOGIN);
  if (!existing) {
    const hash = await argon2.hash(process.env.ADMIN_PASSWORD, {
      type: argon2.argon2id,
      memoryCost: 19456,
      timeCost: 2,
      parallelism: 1
    });
    db.prepare(
      "INSERT INTO users (login, password_hash, created_at) VALUES (?, ?, ?)"
    ).run(process.env.ADMIN_LOGIN, hash, new Date().toISOString());
    console.log("Admin account created.");
  }
})().catch(err => {
  console.error(err);
  process.exit(1);
});

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));

function cookieOptions(maxAge) {
  return [
    `__Host-ft_session=${arguments[0]}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    isProduction ? "Secure" : "",
    `Max-Age=${Math.floor(maxAge / 1000)}`
  ].filter(Boolean).join("; ");
}

function setSessionCookie(res, value, maxAge) {
  res.setHeader("Set-Cookie", cookieOptions(value, maxAge));
}

function clearSessionCookie(res) {
  res.setHeader("Set-Cookie", "__Host-ft_session=; Path=/; HttpOnly; SameSite=Strict; " +
    (isProduction ? "Secure; " : "") + "Max-Age=0");
}

function getSessionId(req) {
  const header = req.headers.cookie || "";
  const match = header.match(/(?:^|;\s*)__Host-ft_session=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

function newSession(userId, twoFactorOk) {
  const id = crypto.randomBytes(32).toString("base64url");
  const expiresAt = Date.now() + 1000 * 60 * 60 * 8;
  db.prepare("INSERT INTO sessions (id,user_id,expires_at,two_factor_ok) VALUES (?,?,?,?)")
    .run(id, userId, expiresAt, twoFactorOk ? 1 : 0);
  return { id, expiresAt };
}

function currentSession(req) {
  const id = getSessionId(req);
  if (!id) return null;
  const session = db.prepare(`
    SELECT s.id, s.user_id, s.expires_at, s.two_factor_ok, u.login
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.id = ?
  `).get(id);

  if (!session || session.expires_at <= Date.now()) {
    if (session) db.prepare("DELETE FROM sessions WHERE id = ?").run(id);
    return null;
  }
  return session;
}

function requireAuth(req, res, next) {
  const session = currentSession(req);
  if (!session || !session.two_factor_ok) {
    return res.status(401).json({ authenticated: false });
  }
  req.session = session;
  next();
}

app.post("/api/login", async (req, res) => {
  const login = String(req.body.login || "").trim();
  const password = String(req.body.password || "");

  const user = db.prepare("SELECT id, login, password_hash FROM users WHERE login = ?").get(login);
  let valid = false;
  if (user) {
    try { valid = await argon2.verify(user.password_hash, password); } catch {}
  }

  if (!valid) {
    // Same response for all credential failures to reduce account enumeration.
    return res.status(401).json({ authenticated: false, message: "Invalid username or password." });
  }

  const session = newSession(user.id, false);
  setSessionCookie(res, session.id, session.expiresAt - Date.now());
  res.json({ authenticated: false, twoFactorRequired: true });
});

app.post("/api/2fa", (req, res) => {
  const session = currentSession(req);
  if (!session) return res.status(401).json({ authenticated: false });

  const code = String(req.body.code || "").replace(/\D/g, "");
  let ok = false;
  try {
    ok = authenticator.check(code, process.env.TOTP_SECRET);
  } catch {}

  if (!ok) return res.status(401).json({ authenticated: false, message: "Invalid code." });

  db.prepare("UPDATE sessions SET two_factor_ok = 1 WHERE id = ?").run(session.id);
  res.json({ authenticated: true });
});

app.get("/api/session", (req, res) => {
  const session = currentSession(req);
  if (!session || !session.two_factor_ok) {
    return res.status(401).json({ authenticated: false });
  }
  res.json({ authenticated: true, login: session.login });
});

app.post("/api/logout", requireAuth, (req, res) => {
  db.prepare("DELETE FROM sessions WHERE id = ?").run(req.session.id);
  clearSessionCookie(res);
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`FT Owner running on http://localhost:${PORT}`);
});
